package DTO;

public interface DTO {
}
