package BLL;

public abstract class MyController {
    public abstract void setValue(Object value);
}
